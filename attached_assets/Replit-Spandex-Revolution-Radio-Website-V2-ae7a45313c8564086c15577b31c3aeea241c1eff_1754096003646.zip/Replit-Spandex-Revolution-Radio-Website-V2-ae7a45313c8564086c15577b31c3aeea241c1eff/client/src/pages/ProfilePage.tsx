import ProfilePage from "@/components/ProfilePageNew";

export default function ProfilePageWrapper() {
  return <ProfilePage />;
}
