export default function TestPage() {
  return (
    <div style={{ padding: '20px', color: 'white', backgroundColor: 'black' }}>
      <h1>Test Page</h1>
      <p>If you can see this, React is working!</p>
    </div>
  );
}