import { jsx as _jsx } from "react/jsx-runtime";
import ProfilePage from "../components/ProfilePageNew";
export default function ProfilePageWrapper() {
    return _jsx(ProfilePage, {});
}
