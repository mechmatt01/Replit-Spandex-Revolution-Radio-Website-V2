export const SOCIALS = [
  { name:'Instagram', url:'#' },
  { name:'Twitter/X', url:'#' },
  { name:'YouTube', url:'#' },
  { name:'TikTok', url:'#' },
  { name:'Facebook', url:'#' },
  { name:'Threads', url:'#' },
];
